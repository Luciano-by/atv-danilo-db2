# Laboratório PostgreSQL + pgAdmin + NGINX

## Estrutura

```text
laboratorio-banco-docker/
├── docker-compose.yml
├── .env
├── .gitignore
├── init/
│   └── 01_init.sql              # seu arquivo atual; não é substituído
└── nginx/
    └── default.conf
```

## 1. Preparar o .env

Copie `.env.example` para `.env`.

No Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Depois abra `.env` e defina uma senha forte para o pgAdmin.

Se o seu PostgreSQL já foi criado com os valores do laboratório atual, mantenha:

```text
POSTGRES_DB=empresa
POSTGRES_USER=admin
POSTGRES_PASSWORD=admin123
```

> Atenção: se o volume `postgres_data` já existe, alterar `POSTGRES_PASSWORD` no `.env` NÃO altera a senha do usuário dentro do PostgreSQL. Esses valores só são usados na inicialização de um banco novo.

## 2. Subir os containers

Na pasta do projeto:

```powershell
docker compose up -d
```

Verifique:

```powershell
docker ps
```

Deve aparecer:

```text
sala-postgres
sala-pgadmin
sala-nginx
```

## 3. Testar o pgAdmin diretamente

Enquanto estamos validando o proxy:

```text
http://localhost:8080
```

ou, de outro PC da LAN:

```text
http://10.10.20.140:8080
```

## 4. Testar o NGINX

No mesmo PC:

```text
http://localhost
```

De outro PC:

```text
http://10.10.20.140
```

O resultado deve ser o pgAdmin.

Fluxo:

```text
Cliente
   |
   | HTTP :80
   v
NGINX (sala-nginx)
   |
   | Docker network "banco"
   v
pgAdmin (sala-pgadmin:80)
   |
   | Docker network "banco"
   v
PostgreSQL (sala-postgres:5432)
```

## 5. Diagnóstico

Ver logs do NGINX:

```powershell
docker logs sala-nginx
```

Testar a configuração dentro do NGINX:

```powershell
docker exec sala-nginx nginx -t
```

Ver a configuração carregada:

```powershell
docker exec sala-nginx nginx -T
```

Ver logs do pgAdmin:

```powershell
docker logs sala-pgadmin
```

## 6. Quando o proxy estiver funcionando

O objetivo final é remover a exposição direta do pgAdmin na porta 8080.

No `docker-compose.yml`, remova:

```yaml
ports:
  - "8080:80"
```

do serviço `pgadmin`.

Depois:

```powershell
docker compose up -d
```

A partir daí:

```text
Internet/LAN
    |
    v
NGINX :80
    |
    v
pgAdmin :80
```

e não haverá mais:

```text
Internet/LAN ---> pgAdmin :8080
```

## 7. Próxima etapa: HTTPS

Este pacote está configurado primeiro para validar o reverse proxy.

Para publicação segura na Internet, a próxima etapa é:

```text
Internet
   |
 HTTPS :443
   |
   v
NGINX
   |
   v
pgAdmin
   |
   v
PostgreSQL
```

Nessa etapa será necessário um domínio (ou outro método apropriado de acesso) e um certificado TLS. Não publique a porta 5432 do PostgreSQL na Internet.

## Observação sobre o banco existente

O Compose usa um volume nomeado:

```text
postgres_data
```

Se você já possui dados no seu `sala-postgres`, não execute `docker compose down -v`, porque `-v` remove os volumes e pode apagar o banco persistido.

Use normalmente:

```powershell
docker compose down
```

e depois:

```powershell
docker compose up -d
```
